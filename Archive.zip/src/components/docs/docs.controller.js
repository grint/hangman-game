class DocsController {
	constructor() {
		this.name = 'docs';
	}
}

export default DocsController;