class NavbarController {
	constructor(sharedUser) {
		this.name = 'navbar';
		this.sharedUser = sharedUser;
	}
}

export default NavbarController;