import angular from 'angular';
import Navbar from './navbar/navbar';

export default angular.module('app.common', [
	Navbar.name,
]);